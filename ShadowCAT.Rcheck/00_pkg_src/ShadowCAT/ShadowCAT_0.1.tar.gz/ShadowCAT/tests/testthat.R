source("testthat/help_functions.R")
library(testthat)
library(jsonlite)
test_check("ShadowCAT")