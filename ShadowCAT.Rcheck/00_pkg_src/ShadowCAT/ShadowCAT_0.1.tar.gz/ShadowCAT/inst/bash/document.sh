R --no-save --quiet -e 'devtools::document()'
