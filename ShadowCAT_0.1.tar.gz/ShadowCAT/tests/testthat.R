source("testthat/help_functions.R")
library(testthat)
test_check("ShadowCAT")